<?php session_start() ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Parallax Template - Materialize</title>

    <!-- CSS  -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
<nav class="white" role="navigation">
    <div class="nav-wrapper container">
        <a id="logo-container" href="index.php" class="brand-logo">Logo</a>
        <ul class="right hide-on-med-and-down">
            <li><a href="signup.php">Sign Up</a></li>
            <li><a href="signin.php">Sign In</a></li>

        </ul>

        <ul id="nav-mobile" class="side-nav">
            <li><a href="#">Navbar Link</a></li>
        </ul>
        <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
</nav>
<div class="container row">
    <div class="col s12 m6">
        <p class="grey-text">
            <?php
                var_dump($_SESSION['regis']);
                $form   =   "
                    <div class='input-field col s6'>
                        <input id='first_name' type='text' class='validate' name='first_name'>
                        <label for='first_name'>First Name</label>
                    </div>
                    <div class='input-field col s6'>
                        <input id='last_name' type='text' class='validate' name='last_name'>
                        <label for='last_name'>Last Name</label>
                    </div>
                    <div class='input-field col s12'>
                        <input id='email' type='email' class='validate' name='email'>
                        <label for='email'>Email</label>
                    </div>
                    <div class='input-field col s12'>
                        <input id='password' type='password' class='validate' name='password'>
                        <label for='password'>Password</label>
                    </div>
                    <div class='input-field col s12'>
                        <input id='signup' type='submit' class='btn' value='next' name='next'>
                    </div>
                ";

                if(isset($_POST['next'])){
                    $first_name =   $_POST['first_name'];
                    $last_name  =   $_POST['last_name'];
                    $email      =   $_POST['email'];
                    $password   =   $_POST['password'];
                    $_SESSION['regis']  = array(
                        'first_name'=>  $first_name,
                        'last_name' =>  $last_name,
                        'email'     =>  $email,
                        'password'  =>  $password
                    );
                    var_dump($_SESSION['regis']);
                    $form       =   "
                        <div class='input-field col s12'>
                            <input type='submit' value='diner' class='btn' name='diner'>
                        </div>
                        <div class='input-field col s12'>
                            <input type='submit' value='owner' class='btn' name='owner'>
                        </div>
                    ";
                }
                elseif (isset($_POST['diner'])){
                    var_dump($_SESSION['regis']);
                    $_SESSION['regis']['diner'] =   true;
                    $form   =   "
                        <div class='input-field col s12'>
                            <textarea id='address' name='address' class='materialize-textarea'></textarea>
                            <label for='address'>Address</label>
                        </div>
                        <div class='input-field col s6'>
                            <input type='text' id='district' name='district'>
                            <label for='district'>Sub/District</label>
                        </div>
                        <div class='input-field col s6'>
                            <input type='text' id='state' name='state'>
                            <label for='state'>Provice/State</label>
                        </div>
                        <div class='input-field col s12'>
                            <input type='text' id='zipcode' name='zipcode'>
                            <label for='zipcode'>Zipcode</label>
                        </div>
                        <div class='input-field col s12'>
                            <input id='signup' type='submit' class='btn' value='signup' name='signup'>
                        </div>
                    ";
                }
                elseif (isset($_POST['owner'])){
                    var_dump($_SESSION['regis']);
                    $_SESSION['regis']['owner'] =   true;
                    $form   =   "
                        <div class='input-field col s6'>
                            <input type='text' id='name' name='name'>
                            <label for='name'>Owner name</label>
                        </div>
                        <div class='input-field col s6'>
                            <input type='text' id='restaurant' name='restaurant'>
                            <label for='restaurant'>Name of Reataurant</label>
                        </div>
                        <div class='input-field col s6'>
                            <input type='text' id='type' name='food_type'>
                            <label for='type'>Type of Food</label>
                        </div>
                        <div class='input-field col s16'>
                            <input type='text' id='address' name='address'>
                            <label for='address'>Address</label>
                        </div>
                        <div class='input-field col s6'>
                            <input type='text' id='state' name='state'>
                            <label for='state'>Provice/State</label>
                        </div>
                        <div class='input-field col s6'>
                            <input type='text' id='zipcode' name='zipcode'>
                            <label for='zipcode'>Zipcode</label>
                        </div>
                         <div class='input-field col s12'>
                            <textarea id='describe' name='describe' class='materialize-textarea'></textarea>
                            <label for='describe'>Description</label>
                        </div>
                        <div class='input-field col s12'>
                            <input id='signup' type='submit' class='btn' value='signup' name='signup'>
                        </div>
                    ";
                }
                elseif (isset($_POST['signup'])) {
                    if (isset($_SESSION['regis']['diner'])) {
                        $address    =   $_POST['address'];
                        $district   =   $_POST['district'];
                        $state      =   $_POST['state'];
                        $zipcode    =   $_POST['zipcode'];
                        var_dump($_SESSION);

                        session_destroy();
                    }
                    elseif (isset($_SESSION['regis']['onwer'])){
                        $name       =   $_POST['name'];
                        $restaurant =   $_POST['restautant'];
                        $type       =   $_POST['type'];
                        $address    =   $_POST['address'];
                        $district   =   $_POST['district'];
                        $state      =   $_POST['state'];
                        $zipcode    =   $_POST['zipcode'];
                        $discribe   =   $_POST['describe'];
                        var_dump($_SESSION);
                        session_destroy();
                    }
                    return;
                }

            /*$db = new mysqli('localhost','root','root','its351');
                if($db->error){
                    die($db->error);
                    return;
                }
                $query  =   "
                    INSERT INTO user (user_email,user_password,created,updated)
                    VALUES ('$email','$password','$created','$updated');
                ";
                if ($result=$db->query($query)==TRUE){
                    echo '<script>console.log("[+]Successfully add user")</script>';
                }
                else{
                    echo '<script>console.log("[-]Could not add user")</script>';
                }

                $db->close();*/
            ?>
        </p>
    </div>
    <div class="col s12 m6">
        <form class="row s12 push-m6 grey-text" action="signup.php" method="post">
            <div class="row">
                <?php echo $form?>
            </div>
        </form>
    </div>
</div>


<footer class="page-footer teal">
    <div class="container">
        <div class="row">
            <div class="col l6 s12">
                <h5 class="white-text">Company Bio</h5>
                <p class="grey-text text-lighten-4">We are a team of
                    college students working on this project like it's our full time job.
                    Any amount would help support and continue development on this project and is greatly appreciated.</p>


            </div>
            <div class="col l3 s12">
                <h5 class="white-text">Settings</h5>
                <ul>
                    <li><a class="white-text" href="#!">Link 1</a></li>
                    <li><a class="white-text" href="#!">Link 2</a></li>
                    <li><a class="white-text" href="#!">Link 3</a></li>
                    <li><a class="white-text" href="#!">Link 4</a></li>
                </ul>
            </div>
            <div class="col l3 s12">
                <h5 class="white-text">Connect</h5>
                <ul>
                    <li><a class="white-text" href="#!">Link 1</a></li>
                    <li><a class="white-text" href="#!">Link 2</a></li>
                    <li><a class="white-text" href="#!">Link 3</a></li>
                    <li><a class="white-text" href="#!">Link 4</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
            Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
        </div>
    </div>
</footer>
<!--  Scripts-->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="js/materialize.js"></script>
<script src="js/init.js"></script>
<!-- active nav bar-->
<script >
    $(function(){
        $('a').each(function(){
            if ($(this).prop('href') == window.location.href) {
                $(this).addClass('active'); $(this).parents('li').addClass('active');
            }
        });
    });
</script>

</body>
</html>
