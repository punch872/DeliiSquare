$(document).ready(function() {
    $('select').material_select();
});
